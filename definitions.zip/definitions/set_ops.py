def print_set(set):
    for i in set:
        print(f"{i}\n")
