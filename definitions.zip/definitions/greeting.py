def greeting():
    return "Hello sunshine"

def author():
    return "Jessie Horvath is the author of this code"

