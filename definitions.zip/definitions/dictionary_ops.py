def print_dict(d):
    for key, value in d.items():
        print(f"{key}, {value}\n")
